-- Live Traffic: loads the GE extension with the mod
load('gameplay_liveTraffic')
setExtensionUnloadMode('gameplay_liveTraffic', 'manual')
