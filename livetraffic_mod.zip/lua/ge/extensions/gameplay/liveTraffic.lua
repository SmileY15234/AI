-- Live Traffic (Живой трафик): richer, more interactive AI traffic.
-- Driving styles, overtaking, staged/natural crashes, emergency services, RP events, chases.
local M = {}
M.dependencies = {'gameplay_traffic', 'gameplay_police'}

local logTag = 'liveTraffic'
local SETTINGS_FILE = 'settings/liveTraffic.json'

local random, floor, max, min, abs = math.random, math.floor, math.max, math.min, math.abs

-------------------------------------------------------------------------------
-- settings
-------------------------------------------------------------------------------
local defaults = {
  enabled = true,
  notify = true,
  style = 'lively',         -- calm | normal | lively | chaos
  overtake = true,
  events = true,            -- random event scheduler
  frequency = 'normal',     -- rare | normal | often
  evAccident = true, evBreakdown = true, evPoliceStop = true, evDrunk = true,
  evRace = true, evSlow = true, evChase = true,
  emergency = true,         -- ambulance / fire / police respond to crashes
  respondToPlayer = true,   -- also react to crashes caused by the player
  sceneSeconds = 100,
}
local S = {}
for k, v in pairs(defaults) do S[k] = v end

-- style presets: share of drivers by archetype + base aggression
local styles = {
  calm   = {aggr = 0.25, p = {normal = 0.80, slow = 0.20, speeder = 0.00, reckless = 0.00}},
  normal = {aggr = 0.35, p = {normal = 0.60, slow = 0.15, speeder = 0.20, reckless = 0.05}},
  lively = {aggr = 0.45, p = {normal = 0.40, slow = 0.12, speeder = 0.33, reckless = 0.15}},
  chaos  = {aggr = 0.60, p = {normal = 0.15, slow = 0.05, speeder = 0.45, reckless = 0.35}},
}
local freqSeconds = { -- {min, max} seconds between random events
  rare = {240, 480}, normal = {110, 260}, often = {45, 110},
}

-------------------------------------------------------------------------------
-- runtime state
-------------------------------------------------------------------------------
local active = false
local timeAcc, tickAcc = 0, 0
local nextEventIn = 90
local styleRec = {}          -- [id] = {style=, rc=respawnCount, overtakeUntil=}
local scenes = {}            -- active crash scenes
local events = {}            -- active running events
local logBuf = {}
local cooldown = {}          -- [eventName] = seconds left
local crashSeen = {}         -- [id] = time of first crash
local providersWanted = {ambulance = true, fire = true}

local function now() return os.clock() end

local function say(msg, level)
  level = level or 'I'
  log(level, logTag, msg)
  table.insert(logBuf, os.date('%H:%M:%S') .. '  ' .. msg)
  while #logBuf > 14 do table.remove(logBuf, 1) end
end

local function toast(msg)
  say(msg)
  if S.notify and ui_message then pcall(ui_message, msg, 6, 'liveTraffic', 'warning') end
end

local function save()
  pcall(jsonWriteFile, SETTINGS_FILE, S, true)
end

local function load_()
  local ok, data = pcall(jsonReadFile, SETTINGS_FILE)
  if ok and type(data) == 'table' then
    for k, v in pairs(data) do
      if defaults[k] ~= nil and type(v) == type(defaults[k]) then S[k] = v end
    end
  end
end

-------------------------------------------------------------------------------
-- helpers
-------------------------------------------------------------------------------
local function trafficData()
  local ok, t = pcall(gameplay_traffic.getTrafficData)
  return ok and t or {}
end

local function obj(id) return id and getObjectByID(id) or nil end

local function cmd(id, str)
  local o = obj(id)
  if o then o:queueLuaCommand(str) end
end

local function focusPos()
  local f = gameplay_traffic.getFocus and gameplay_traffic.getFocus()
  if f and f.pos then return f.pos end
  local pv = be:getPlayerVehicle(0)
  return pv and pv:getPosition() or vec3(0, 0, 0)
end

local function isPlain(veh)
  return veh and veh.isAi and not veh.reserved and not veh.claimed
    and veh.roleName == 'standard' and not veh.isPerson
    and veh.pos and obj(veh.id) and obj(veh.id):getActive()
    and veh.id ~= be:getPlayerVehicleID(0)
end

-- AI traffic vehicles currently free for scripting, optionally within a distance band of the focus
local function candidates(minD, maxD, filter)
  local out, fp = {}, focusPos()
  for id, veh in pairs(trafficData()) do
    if isPlain(veh) and not veh._ltBusy then
      local d = veh.pos:distance(fp)
      if d >= (minD or 0) and d <= (maxD or 1e9) and (not filter or filter(veh, d)) then
        out[#out + 1] = veh
      end
    end
  end
  return out
end

local function pick(list)
  if #list == 0 then return nil end
  return list[random(#list)]
end

local function busy(veh, v) if veh then veh._ltBusy = v and true or nil end end

local function releaseVeh(id)
  local veh = trafficData()[id]
  if not veh then return end
  veh._ltBusy = nil
  veh.enableRespawn = true
  pcall(function() veh.role:resetAction() end)
  cmd(id, 'ai.setPullOver(false) electrics.set_warn_signal(0) electrics.horn(false)')
  cmd(id, 'ai.setAvoidCars("on") ai.setMode("traffic")')
  pcall(function() veh:setAiParameters(gameplay_traffic.getTrafficVars()) end)
  styleRec[id] = nil -- style gets re-applied
end

-- vector from a to b normalised on the XY plane
local function dir2(a, b)
  local d = vec3(b.x - a.x, b.y - a.y, 0)
  local l = d:length()
  if l < 1e-6 then return vec3(0, 1, 0) end
  return d / l
end

-- put a vehicle on the road `dist` metres behind/ahead of a point
local function placeOnRoad(id, pos, dir, minD, maxD, targetD, speed)
  local tu = gameplay_traffic_trafficUtils
  local ok, sd = pcall(tu.findSafeSpawnPoint, pos, dir, minD, maxD, targetD, {})
  if not ok or not sd or not sd.pos then return false end
  local ok2, newPos, newDir = pcall(tu.finalizeSpawnPoint, sd.pos, sd.dir, sd.n1, sd.n2, {legalDirection = true})
  if not ok2 or not newPos then return false end
  local rot = quatFromDir(newDir, map.surfaceNormal(newPos))
  gameplay_traffic.respawnVehicle(id, newPos, rot, false)
  local veh = trafficData()[id]
  if veh and speed then veh.respawnSpeed = speed end
  return true, newPos
end

-------------------------------------------------------------------------------
-- driving styles
-------------------------------------------------------------------------------
local function rollArchetype()
  local p = (styles[S.style] or styles.normal).p
  local r, acc = random(), 0
  for _, k in ipairs({'normal', 'slow', 'speeder', 'reckless'}) do
    acc = acc + (p[k] or 0)
    if r <= acc then return k end
  end
  return 'normal'
end

local function applyArchetype(veh, arch)
  local id = veh.id
  local base = (styles[S.style] or styles.normal).aggr
  local limit = (veh.tracking and veh.tracking.speedLimit) or 18
  if limit < 8 then limit = 18 end
  if arch == 'slow' then
    cmd(id, string.format('ai.setAggression(%.2f) ai.setSpeedMode("limit") ai.setSpeed(%.1f)', base * 0.6, limit * 0.65))
  elseif arch == 'speeder' then
    cmd(id, string.format('ai.setAggression(%.2f) ai.setSpeedMode("limit") ai.setSpeed(%.1f)', min(0.9, base + 0.3), limit * 1.35))
  elseif arch == 'reckless' then
    cmd(id, string.format('ai.setAggression(%.2f) ai.setSpeedMode("limit") ai.setSpeed(%.1f)', min(1, base + 0.5), limit * 1.7))
  else
    cmd(id, string.format('ai.setAggression(%.2f) ai.setSpeedMode("legal")', base))
  end
end

local function updateStyles()
  for id, veh in pairs(trafficData()) do
    if isPlain(veh) and not veh._ltBusy then
      local rec = styleRec[id]
      if not rec or rec.rc ~= veh.respawnCount or rec.style ~= S.style then
        rec = {style = S.style, rc = veh.respawnCount, arch = rollArchetype(), over = 0}
        styleRec[id] = rec
        applyArchetype(veh, rec.arch)
      end
    end
  end
  for id in pairs(styleRec) do
    if not trafficData()[id] then styleRec[id] = nil end
  end
end

-------------------------------------------------------------------------------
-- overtaking (lane-free pass for pushy drivers)
-------------------------------------------------------------------------------
local function updateOvertakes(dt)
  local all = trafficData()
  for id, rec in pairs(styleRec) do
    local veh = all[id]
    if veh and rec.over > 0 then
      rec.over = rec.over - dt
      if rec.over <= 0 then
        cmd(id, 'ai.driveInLane("on")')
        applyArchetype(veh, rec.arch)
      end
    elseif veh and not veh._ltBusy and (rec.arch == 'speeder' or rec.arch == 'reckless') and veh.speed > 6 and S.overtake then
      -- look for a slower car ahead in the same direction and no oncoming traffic on the passing side
      local lead, oncoming
      for oid, o in pairs(all) do
        if oid ~= id and o.pos and o.dirVec then
          local to = o.pos - veh.pos
          local dist = to:length()
          if dist < 140 then
            local fwd = to:dot(veh.dirVec)
            local lat = abs(to:cross(veh.dirVec).z)
            local same = o.dirVec:dot(veh.dirVec)
            if fwd > 0 and lat < 3 then
              if same > 0.8 and dist < 38 and o.speed < veh.speed - 3 then lead = lead or o end
              if same < -0.5 then oncoming = true end
            elseif fwd > 0 and lat < 8 and same < -0.5 and dist < 140 then
              oncoming = true
            end
          end
        end
      end
      local pl = be:getPlayerVehicle(0)
      if pl and not oncoming then
        local pp = pl:getPosition()
        local to = pp - veh.pos
        local pd = vec3(pl:getDirectionVector())
        if to:length() < 140 and to:dot(veh.dirVec) > 0 and abs(to:cross(veh.dirVec).z) < 8 and pd:dot(veh.dirVec) < -0.5 then oncoming = true end
      end
      if lead and not oncoming and random() < 0.5 then
        rec.over = 7
        cmd(id, 'ai.driveInLane("off") ai.setAggression(0.9)')
        pcall(function() veh:honkHorn(0.5) end)
      end
    end
  end
end

-------------------------------------------------------------------------------
-- emergency services
-------------------------------------------------------------------------------
local configCache = {}

-- find a plausible config for emergency vehicles at runtime (no hard-coded stock names)
local function findEmergencyConfig(kind)
  if configCache[kind] ~= nil then return configCache[kind] or nil end
  local words = (kind == 'ambulance') and {'ambulance', 'medic', 'paramedic'} or {'fire', 'firetruck', 'firedept', 'fd_'}
  local found
  local ok, models = pcall(function() return core_vehicles.getModelList().models end)
  if ok and type(models) == 'table' then
    for mname, m in pairs(models) do
      local mn = string.lower(mname)
      local hit = false
      for _, w in ipairs(words) do if string.find(mn, w, 1, true) then hit = true end end
      local okc, cl = pcall(function() return core_vehicles.getModel(mname).configs end)
      if okc and type(cl) == 'table' then
        for ckey, c in pairs(cl) do
          local ck = string.lower(ckey)
          local chit = hit
          for _, w in ipairs(words) do if string.find(ck, w, 1, true) then chit = true end end
          if chit and not found then found = {model = mname, config = ckey} end
        end
      end
    end
    -- fall back: any 'Service' config type on a van/truck
    if not found then
      for mname in pairs(models) do
        local okc, cl = pcall(function() return core_vehicles.getModel(mname).configs end)
        if okc and type(cl) == 'table' then
          for ckey, c in pairs(cl) do
            local ct = string.lower(c['Config Type'] or '')
            local ck = string.lower(ckey)
            if ct == 'service' and (kind == 'fire' and (string.find(ck, 'fire') or string.find(ck, 'rescue')) or kind == 'ambulance' and (string.find(ck, 'amb') or string.find(ck, 'medic'))) and not found then
              found = {model = mname, config = ckey}
            end
          end
        end
      end
    end
  end
  configCache[kind] = found or false
  if found then say(string.format('%s: %s / %s', kind, found.model, found.config))
  else say('Нет подходящей машины для: ' .. kind .. ' (в игре не найден конфиг)', 'W') end
  return found
end

function M.onTrafficSpecialVehiclesProviders()
  for _, kind in ipairs({'ambulance', 'fire'}) do
    gameplay_traffic.registerSpecialVehicleProvider({
      name = 'live_' .. kind,
      priority = 5,
      minTotalAmount = 4,
      getDesiredCount = function() return 0 end,
      reserved = 1,
      buildGroup = function(count)
        local cfg = S.emergency and findEmergencyConfig(kind)
        local g = {}
        if cfg then for i = 1, count do g[i] = {model = cfg.model, config = cfg.config} end end
        return g
      end,
    })
  end
end

local function ensureReserves()
  if not S.emergency then return end
  for _, kind in ipairs({'ambulance', 'fire'}) do
    local has = false
    for _, veh in pairs(trafficData()) do
      if veh.reserved == 'live_' .. kind then has = true end
    end
    if not has and findEmergencyConfig(kind) then
      pcall(gameplay_traffic.ensureReservedVehicles, 'live_' .. kind, 1)
    end
  end
end

local function sirenOn(id, on)
  if on then cmd(id, 'electrics.set_lightbar_signal(2)') else cmd(id, 'electrics.set_lightbar_signal(0)') end
end

local function dispatch(kind, scene)
  -- returns responder record or nil
  local id
  if kind == 'police' then
    local best, bd = nil, 1e9
    for pid, pv in pairs(gameplay_police.getPoliceVehicles() or {}) do
      local t = trafficData()[pid]
      if t and not t._ltBusy and not t.claimed and t.role and not t.role.targetId and pid ~= be:getPlayerVehicleID(0)
         and not (gameplay_police.isVehicleInPursuit and gameplay_police.isVehicleInPursuit(pid)) then
        local d = t.pos:distance(scene.pos)
        if d < bd then best, bd = pid, d end
      end
    end
    id = best
  else
    local ok, claimed = pcall(gameplay_traffic.useReservedVehicle, 'live_' .. kind, 1)
    id = ok and claimed and claimed[1] or nil
  end
  if not id then return nil end
  local veh = trafficData()[id]
  if not veh then return nil end
  veh._ltBusy = true
  local back = -(scene.dir or vec3(0, 1, 0))
  local placed = placeOnRoad(id, scene.pos, back, 220, 420, 300, 12)
  if not placed then
    -- fall back: keep original location
    say(kind .. ': не нашёл точку выезда, еду с текущего места', 'W')
  end
  local rec = {id = id, kind = kind, state = 'drive', t = 0, tReady = nil}
  veh.enableRespawn = false
  rec.kickoff = 1.0
  return rec
end

local function startResponderAI(rec, scene)
  sirenOn(rec.id, true)
  local target = scene.vehIds[1]
  cmd(rec.id, string.format('ai.setMode("follow") ai.setTargetObjectID(%d) ai.setAggression(0.85) ai.setSpeedMode("off") ai.driveInLane("off") ai.setAvoidCars("on")', target))
  pcall(function() trafficData()[rec.id]:honkHorn(1.0) end)
end

-- slow down / pull over civilians that a siren is approaching from behind
local function yieldTraffic(rec)
  local ev = trafficData()[rec.id]
  if not ev or not ev.pos then return end
  for id, veh in pairs(trafficData()) do
    if id ~= rec.id and isPlain(veh) and not events[id] and veh.pos then
      local to = veh.pos - ev.pos
      local d = to:length()
      if d < 70 and to:dot(ev.dirVec) > 0 and veh.dirVec:dot(ev.dirVec) > 0.5 and ev.speed > 5 then
        if not veh._ltYield then
          veh._ltYield = now()
          cmd(id, 'ai.setPullOver(true)')
        end
      elseif veh._ltYield and (d > 90 or to:dot(ev.dirVec) < 0 or now() - veh._ltYield > 20) then
        veh._ltYield = nil
        cmd(id, 'ai.setPullOver(false)')
      end
    end
  end
end

local function endScene(scene, why)
  for _, rec in ipairs(scene.responders) do
    sirenOn(rec.id, false)
    local veh = trafficData()[rec.id]
    if veh then
      veh._ltBusy = nil
      veh.enableRespawn = true
      cmd(rec.id, 'ai.setMode("traffic") ai.driveInLane("on") ai.setSpeedMode("legal") ai.setAvoidCars("on")')
      if rec.kind ~= 'police' then
        pcall(gameplay_traffic.returnReservedVehicle, rec.id)
      end
    end
  end
  for _, id in ipairs(scene.vehIds) do
    local veh = trafficData()[id]
    if veh then veh.enableRespawn = true; veh._ltBusy = nil end
  end
  say('Сцена ДТП закрыта' .. (why and (' (' .. why .. ')') or ''))
end

local function createScene(vehIds, pos, dir, severity, label)
  -- avoid duplicates near an existing scene
  for _, sc in ipairs(scenes) do
    if sc.pos:distance(pos) < 60 then return sc end
  end
  local scene = {vehIds = vehIds, pos = vec3(pos), dir = dir or vec3(0, 1, 0), severity = severity or 1,
                 responders = {}, t = 0, label = label or 'ДТП', timeout = S.sceneSeconds}
  for _, id in ipairs(vehIds) do
    local veh = trafficData()[id]
    if veh then veh.enableRespawn = false; veh._ltBusy = true; pcall(function() veh:modifyRespawnValues(1000) end) end
  end
  table.insert(scenes, scene)
  toast(string.format('%s! Вызваны службы.', scene.label))
  if S.emergency then
    ensureReserves()
    local want = {'police'}
    if severity >= 1 then want[#want + 1] = 'ambulance' end
    if severity >= 2 then want[#want + 1] = 'fire' end
    scene.pending = want
    scene.dispatchIn = 4
  end
  return scene
end

local function updateScenes(dt)
  for i = #scenes, 1, -1 do
    local sc = scenes[i]
    sc.t = sc.t + dt
    if sc.pending and sc.t >= sc.dispatchIn then
      local stillPending = {}
      for _, kind in ipairs(sc.pending) do
        local rec = dispatch(kind, sc)
        if rec then table.insert(sc.responders, rec)
        else table.insert(stillPending, kind) end
      end
      sc.tries = (sc.tries or 0) + 1
      if #stillPending > 0 and sc.tries < 4 then
        sc.pending = stillPending; sc.dispatchIn = sc.t + 6
      else
        if #stillPending > 0 then say('Не удалось вызвать: ' .. table.concat(stillPending, ', ') .. ' (нет свободной машины)', 'W') end
        sc.pending = nil
      end
    end
    local allReady = #sc.responders > 0
    for _, rec in ipairs(sc.responders) do
      rec.t = rec.t + dt
      local veh = trafficData()[rec.id]
      if not veh then rec.state = 'gone'
      else
        if rec.kickoff and rec.t >= rec.kickoff then rec.kickoff = nil; startResponderAI(rec, sc) end
        if rec.state == 'drive' then
          yieldTraffic(rec)
          local d = veh.pos:distance(sc.pos)
          if d < 30 and veh.speed < 3 or (d < 14) then
            rec.state = 'onScene'; rec.tReady = sc.t
            cmd(rec.id, 'ai.setMode("stop")')
            if rec.kind == 'fire' then cmd(rec.id, 'electrics.set_warn_signal(1)') end
          elseif rec.t > 150 and d > 150 then
            -- stuck / too far: teleport closer once
            if not rec.warped then
              rec.warped = true
              placeOnRoad(rec.id, sc.pos, -sc.dir, 80, 160, 110, 8)
              rec.kickoff = 1
            end
          end
        end
        if rec.state ~= 'onScene' and rec.state ~= 'gone' then allReady = false end
      end
    end
    local arrived = allReady and not sc.pending
    if arrived and not sc.arrivedAt then sc.arrivedAt = sc.t; say('Службы на месте ДТП') end
    local expire = (sc.arrivedAt and sc.t - sc.arrivedAt > sc.timeout) or sc.t > sc.timeout + 240
    if expire then endScene(sc, 'готово'); table.remove(scenes, i) end
  end
end

-- natural + player-caused crash detection
local function onCrash(id, data)
  if not S.enabled or not active then return end
  if crashSeen[id] then return end
  local veh = trafficData()[id]
  if not veh then return end
  if veh.reserved or veh.roleName == 'police' then return end
  if id == be:getPlayerVehicleID(0) and not S.respondToPlayer then return end
  crashSeen[id] = now()
end

local function checkCrashes()
  for id, t0 in pairs(crashSeen) do
    local veh = trafficData()[id]
    if not veh then crashSeen[id] = nil
    elseif now() - t0 > 4 then
      crashSeen[id] = nil
      local dmg = veh.damage or 0
      if dmg > 250 and veh.speed < 6 then
        local sev = dmg > 3000 and 2 or (dmg > 900 and 1 or 0)
        local ids = {id}
        for oid, ov in pairs(trafficData()) do
          if oid ~= id and ov.pos and ov.pos:distance(veh.pos) < 20 and (ov.damage or 0) > 250 and not ov.reserved then ids[#ids + 1] = oid end
        end
        createScene(ids, veh.pos, veh.dirVec, sev, sev >= 2 and 'Тяжёлое ДТП' or 'ДТП')
      end
    end
  end
end

-------------------------------------------------------------------------------
-- events
-------------------------------------------------------------------------------
local E = {} -- event implementations; each returns true if started

local function addEvent(name, data)
  data.name, data.t = name, 0
  table.insert(events, data)
end

-- staged crash: leader brakes hard, follower ignores avoidance (rear-end / pile-up)
E.accident = function()
  local fp = focusPos()
  local pairsFound = {}
  local list = candidates(60, 320, function(v) return v.speed > 6 end)
  for _, a in ipairs(list) do
    for _, b in ipairs(list) do
      if a ~= b then
        local to = a.pos - b.pos
        local d = to:length()
        if d > 12 and d < 55 and to:dot(b.dirVec) / d > 0.96 and a.dirVec:dot(b.dirVec) > 0.9 then
          pairsFound[#pairsFound + 1] = {lead = a, fol = b}
        end
      end
    end
  end
  local p = pick(pairsFound)
  if not p then return false end
  local group = {p.lead, p.fol}
  -- optional chain: a third car behind the follower
  if random() < 0.5 then
    for _, c in ipairs(list) do
      local to = p.fol.pos - c.pos
      local d = to:length()
      if c ~= p.fol and c ~= p.lead and d > 10 and d < 45 and to:dot(c.dirVec) / d > 0.96 then group[#group + 1] = c; break end
    end
  end
  for _, v in ipairs(group) do busy(v, true) end
  cmd(p.lead.id, 'ai.setSpeedMode("limit") ai.setSpeed(0) ai.setAggression(1)')
  for i = 2, #group do
    cmd(group[i].id, 'ai.setAvoidCars("off") ai.setSpeedMode("off") ai.setAggression(1)')
  end
  addEvent('accident', {ids = (function() local r = {} for _, v in ipairs(group) do r[#r + 1] = v.id end return r end)(), dur = 14})
  say('Событие: аварийное торможение, ' .. #group .. ' машины')
  return true
end

E.breakdown = function()
  local v = pick(candidates(50, 300, function(x) return x.speed > 4 end))
  if not v then return false end
  busy(v, true)
  cmd(v.id, 'ai.setPullOver(true) electrics.set_warn_signal(1)')
  addEvent('breakdown', {ids = {v.id}, dur = random(60, 120)})
  say('Событие: машина сломалась у дороги')
  return true
end

E.slow = function()
  local v = pick(candidates(40, 260, function(x) return x.speed > 4 end))
  if not v then return false end
  busy(v, true)
  cmd(v.id, 'ai.setAggression(0.15) ai.setSpeedMode("limit") ai.setSpeed(7) electrics.set_warn_signal(1)')
  addEvent('slow', {ids = {v.id}, dur = random(60, 110)})
  say('Событие: медленный водитель')
  return true
end

E.drunk = function()
  local v = pick(candidates(50, 280, function(x) return x.speed > 4 end))
  if not v then return false end
  busy(v, true)
  cmd(v.id, 'ai.setMode("random") ai.driveInLane("off") ai.setAggression(0.25) ai.setSpeedMode("limit") ai.setSpeed(13)')
  addEvent('drunk', {ids = {v.id}, dur = random(35, 55), swerve = 0, chase = S.evChase and random() < 0.6})
  say('Событие: нетрезвый водитель')
  return true
end

E.race = function()
  local list = candidates(50, 260, function(x) return x.speed > 8 end)
  local a = pick(list)
  if not a then return false end
  local b
  for _, c in ipairs(list) do
    if c ~= a and c.pos:distance(a.pos) < 40 and c.dirVec:dot(a.dirVec) > 0.9 then b = c; break end
  end
  if not b then return false end
  busy(a, true); busy(b, true)
  for _, v in ipairs({a, b}) do
    cmd(v.id, 'ai.setAggression(1) ai.setSpeedMode("off") ai.driveInLane("off")')
    pcall(function() v:honkHorn(0.4) end)
  end
  addEvent('race', {ids = {a.id, b.id}, dur = 28, chase = S.evChase and random() < 0.5})
  say('Событие: уличная гонка')
  return true
end

local function startChase(suspectId)
  local police = gameplay_police.getPoliceVehicles() or {}
  local sv = trafficData()[suspectId]
  if not sv then return false end
  local near = {}
  for pid, pv in pairs(police) do
    local t = trafficData()[pid]
    if t and t.pos and not t.claimed and pid ~= be:getPlayerVehicleID(0) then
      near[#near + 1] = {id = pid, d = t.pos:distance(sv.pos)}
    end
  end
  table.sort(near, function(a, b) return a.d < b.d end)
  if #near == 0 then say('Погоня: в трафике нет полиции (включи полицию в настройках трафика)', 'W'); return false end
  local ids = {}
  for i = 1, min(2, #near) do
    ids[#ids + 1] = near[i].id
    if near[i].d > 250 then
      busy(trafficData()[near[i].id], true)
      placeOnRoad(near[i].id, sv.pos, -sv.dirVec, 120, 220, 160, 15)
    end
  end
  sv._ltBusy = true
  cmd(suspectId, 'ai.setAvoidCars("on")')
  addEvent('chaseStart', {ids = {suspectId}, police = ids, delay = 1.2, dur = 1.2, suspect = suspectId})
  toast('Погоня! Полиция преследует нарушителя.')
  return true
end

E.chase = function()
  local v = pick(candidates(60, 300, function(x) return x.speed > 6 end))
  if not v then return false end
  return startChase(v.id)
end

E.policeStop = function()
  local cop
  for pid in pairs(gameplay_police.getPoliceVehicles() or {}) do
    local t = trafficData()[pid]
    if t and t.pos and not t._ltBusy and not t.claimed and pid ~= be:getPlayerVehicleID(0) and t.role and not t.role.targetId
       and t.pos:distance(focusPos()) < 500 then cop = t; break end
  end
  if not cop then return false end
  local v = pick(candidates(30, 350, function(x, d) return x.speed > 5 end))
  if not v then return false end
  busy(v, true); busy(cop, true)
  if cop.pos:distance(v.pos) > 200 then placeOnRoad(cop.id, v.pos, -v.dirVec, 80, 160, 110, 14) end
  sirenOn(cop.id, true)
  cmd(cop.id, string.format('ai.setMode("follow") ai.setTargetObjectID(%d) ai.setAggression(0.7) ai.setSpeedMode("off")', v.id))
  addEvent('policeStop', {ids = {v.id, cop.id}, cop = cop.id, civ = v.id, dur = 90, stage = 'approach'})
  say('Событие: остановка полицией')
  return true
end

local function endEvent(ev)
  for _, id in ipairs(ev.ids or {}) do
    local veh = trafficData()[id]
    if veh then releaseVeh(id) end
  end
  if ev.name == 'policeStop' and ev.cop then sirenOn(ev.cop, false) end
end

local function updateEvents(dt)
  for i = #events, 1, -1 do
    local ev = events[i]
    ev.t = ev.t + dt
    local alive = true
    for _, id in ipairs(ev.ids or {}) do if not trafficData()[id] then alive = false end end
    if not alive then endEvent(ev); table.remove(events, i)
    elseif ev.name == 'drunk' then
      ev.swerve = ev.swerve + dt
      if ev.swerve > 2.5 then
        ev.swerve = 0
        cmd(ev.ids[1], 'ai.reset()')
        if random() < 0.3 then pcall(function() trafficData()[ev.ids[1]]:honkHorn(0.3) end) end
      end
      if ev.chase and ev.t > 18 and not ev.chased then
        ev.chased = true
        local sid = ev.ids[1]
        if startChase(sid) then ev.t = ev.dur end -- hand over to the pursuit system
        ev.ids = {}
      end
      if ev.t >= ev.dur then endEvent(ev); table.remove(events, i) end
    elseif ev.name == 'race' then
      if ev.chase and ev.t > 18 and not ev.chased then
        ev.chased = true
        local sid = ev.ids[random(#ev.ids)]
        local rest = {}
        for _, id in ipairs(ev.ids) do if id ~= sid then rest[#rest + 1] = id end end
        ev.ids = rest
        startChase(sid)
      end
      if ev.t >= ev.dur then endEvent(ev); table.remove(events, i) end
    elseif ev.name == 'chaseStart' then
      if ev.delay and ev.t >= ev.delay then
        ev.delay = nil
        for _, pid in ipairs(ev.police) do local t = trafficData()[pid]; if t then t._ltBusy = nil end end
        pcall(gameplay_police.setPursuitMode, 2, ev.suspect, ev.police)
        local t = trafficData()[ev.suspect]; if t then t._ltBusy = nil end
        table.remove(events, i)
      end
    elseif ev.name == 'policeStop' then
      local cop, civ = trafficData()[ev.cop], trafficData()[ev.civ]
      if ev.stage == 'approach' and cop and civ and cop.pos:distance(civ.pos) < 45 then
        ev.stage = 'stopped'; ev.tStop = ev.t
        cmd(ev.civ, 'ai.setPullOver(true) electrics.set_warn_signal(1)')
      elseif ev.stage == 'stopped' and cop and cop.pos:distance(civ.pos) < 18 and cop.speed < 1 then
        cmd(ev.cop, 'ai.setMode("stop")')
      end
      if ev.t >= ev.dur or (ev.stage == 'approach' and ev.t > 70) then endEvent(ev); table.remove(events, i) end
    elseif ev.name == 'accident' then
      if ev.t >= ev.dur then
        for _, id in ipairs(ev.ids) do local v = trafficData()[id]; if v then v._ltBusy = nil end end
        -- vehicles that crashed are picked up by the crash detector; the rest resume
        local crashed = {}
        for _, id in ipairs(ev.ids) do
          local v = trafficData()[id]
          if v and (v.damage or 0) > 250 then crashed[#crashed + 1] = id end
        end
        for _, id in ipairs(ev.ids) do
          local v = trafficData()[id]
          local isCrashed = false
          for _, c in ipairs(crashed) do if c == id then isCrashed = true end end
          if v and not isCrashed then releaseVeh(id) end
        end
        if #crashed > 0 then
          local v = trafficData()[crashed[1]]
          if v then createScene(crashed, v.pos, v.dirVec, (v.damage > 3000) and 2 or 1, 'ДТП') end
        end
        table.remove(events, i)
      end
    else -- breakdown, slow
      if ev.t >= ev.dur then endEvent(ev); table.remove(events, i) end
    end
  end
end

local evKeys = {
  accident = 'evAccident', breakdown = 'evBreakdown', policeStop = 'evPoliceStop',
  drunk = 'evDrunk', race = 'evRace', slow = 'evSlow', chase = 'evChase',
}
local evWeights = {accident = 3, breakdown = 3, policeStop = 2, drunk = 2, race = 2, slow = 3, chase = 2}
local evOrder = {'accident', 'breakdown', 'policeStop', 'drunk', 'race', 'slow', 'chase'}

local function runEvent(name, forced)
  if not E[name] then return false end
  local ok, res = pcall(E[name])
  if not ok then say('Ошибка события ' .. name .. ': ' .. tostring(res), 'E'); return false end
  if not res and forced then say('Событие «' .. name .. '» не запустилось: нет подходящих машин рядом', 'W') end
  if res then cooldown[name] = 40 end
  return res
end

local function scheduleNext()
  local f = freqSeconds[S.frequency] or freqSeconds.normal
  nextEventIn = f[1] + random() * (f[2] - f[1])
end

local function pickRandomEvent()
  local pool, total = {}, 0
  for _, name in ipairs(evOrder) do
    if S[evKeys[name]] and (cooldown[name] or 0) <= 0 then
      pool[#pool + 1] = name; total = total + evWeights[name]
    end
  end
  local r = random() * total
  for _, name in ipairs(pool) do
    r = r - evWeights[name]
    if r <= 0 then return name end
  end
  return pool[1]
end

-------------------------------------------------------------------------------
-- main loop
-------------------------------------------------------------------------------
local function tick(dt)
  if gameplay_traffic.getState and gameplay_traffic.getState() ~= 'on' then return end
  updateStyles()
  updateOvertakes(dt)
  checkCrashes()
  updateScenes(dt)
  updateEvents(dt)
  for k, v in pairs(cooldown) do cooldown[k] = v - dt end
  if S.events then
    nextEventIn = nextEventIn - dt
    if nextEventIn <= 0 then
      scheduleNext()
      local name = pickRandomEvent()
      if name then
        local tries = 0
        while name and tries < 3 do
          if runEvent(name) then break end
          cooldown[name] = 15
          name = pickRandomEvent(); tries = tries + 1
        end
      end
    end
  end
  if S.emergency and (timeAcc % 20) < dt then ensureReserves() end
end

function M.onUpdate(dtReal, dtSim)
  if not active or not S.enabled then return end
  timeAcc = timeAcc + dtSim
  tickAcc = tickAcc + dtSim
  if tickAcc >= 0.5 then
    local dt = tickAcc
    tickAcc = 0
    local ok, err = pcall(tick, dt)
    if not ok then
      M._errCount = (M._errCount or 0) + 1
      if M._errCount < 6 then say('Ошибка тика: ' .. tostring(err), 'E') end
    end
  end
end

-------------------------------------------------------------------------------
-- hooks
-------------------------------------------------------------------------------
local function resetRuntime()
  for _, sc in ipairs(scenes) do pcall(endScene, sc, 'сброс') end
  scenes, events, styleRec, crashSeen, cooldown = {}, {}, {}, {}, {}
  for _, veh in pairs(trafficData()) do veh._ltBusy = nil; veh._ltYield = nil end
end

function M.onTrafficStarted()
  active = true
  timeAcc, tickAcc = 0, 0
  scheduleNext()
  nextEventIn = max(nextEventIn, 40) -- let traffic settle first
  local st = styles[S.style] or styles.normal
  pcall(gameplay_traffic.setTrafficVars, {baseAggression = st.aggr})
  say('Трафик запущен — Живой трафик активен (стиль: ' .. S.style .. ')')
  ensureReserves()
end

function M.onTrafficStopped()
  resetRuntime()
  active = false
end

function M.onTrafficVehicleCrashed(id, data) onCrash(id, data) end
function M.onClientEndMission() resetRuntime(); active = false end
function M.onExtensionLoaded() load_() end
function M.onSerialize() resetRuntime(); return {} end

-------------------------------------------------------------------------------
-- public API for the UI app
-------------------------------------------------------------------------------
function M.getStateJson()
  local evNames = {}
  for _, e in ipairs(events) do evNames[#evNames + 1] = e.name end
  local resp = 0
  for _, sc in ipairs(scenes) do resp = resp + #sc.responders end
  local pol = 0
  for _ in pairs(gameplay_police.getPoliceVehicles() or {}) do pol = pol + 1 end
  return jsonEncode({
    settings = S, active = active, nextIn = floor(nextEventIn),
    scenes = #scenes, responders = resp, events = evNames, police = pol,
    traffic = gameplay_traffic.getNumOfTraffic and gameplay_traffic.getNumOfTraffic() or 0,
    log = logBuf,
  })
end

function M.setSettings(patch)
  if type(patch) ~= 'table' then return end
  for k, v in pairs(patch) do
    if defaults[k] ~= nil and type(v) == type(defaults[k]) then S[k] = v end
  end
  if patch.style and styles[S.style] then
    pcall(gameplay_traffic.setTrafficVars, {baseAggression = styles[S.style].aggr})
    styleRec = {}
  end
  if patch.frequency then scheduleNext() end
  save()
end

function M.setSettingsJson(str)
  local ok, t = pcall(jsonDecode, str)
  if ok then M.setSettings(t) end
end

function M.trigger(name)
  if not active then toast('Трафик не запущен. Включи трафик в меню (Traffic).'); return false end
  if name == 'ambulanceCall' then
    local v = pick(candidates(60, 250))
    if v then createScene({v.id}, v.pos, v.dirVec, 1, 'Вызов скорой'); return true end
    return false
  elseif name == 'fireCall' then
    local v = pick(candidates(60, 250))
    if v then createScene({v.id}, v.pos, v.dirVec, 2, 'Пожар на дороге'); return true end
    return false
  end
  return runEvent(name, true)
end

function M.clearAll()
  resetRuntime()
  say('Все события сброшены')
end

M.dumpLog = function() return logBuf end

return M
