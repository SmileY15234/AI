angular.module('beamng.apps').directive('trafficdirector', ['$interval', function ($interval) {
  return {
    templateUrl: '/ui/modules/apps/TrafficDirector/app.html',
    replace: true,
    restrict: 'EA',
    scope: true,
    link: function (scope, element) {
      scope.st = null;
      scope.tab = 'main';
      scope.styles = [['calm', 'Спокойный'], ['normal', 'Обычный'], ['lively', 'Живой'], ['chaos', 'Хаос']];
      scope.freqs = [['rare', 'Редко'], ['normal', 'Средне'], ['often', 'Часто']];
      scope.toggles = [
        ['overtake', 'Обгоны'], ['events', 'Случайные события'], ['emergency', 'Скорая/пожарные/полиция'],
        ['respondToPlayer', 'Реагировать на мои ДТП'], ['notify', 'Уведомления'],
        ['evAccident', 'ДТП (подстроенные)'], ['evBreakdown', 'Поломки'], ['evPoliceStop', 'Остановки полицией'],
        ['evDrunk', 'Пьяный водитель'], ['evRace', 'Уличные гонки'], ['evSlow', 'Тихоходы'], ['evChase', 'Погони']
      ];
      scope.triggers = [
        ['accident', 'ДТП'], ['breakdown', 'Поломка'], ['policeStop', 'Остановка'], ['drunk', 'Пьяный'],
        ['race', 'Гонка'], ['slow', 'Тихоход'], ['chase', 'Погоня'], ['ambulanceCall', 'Скорая'], ['fireCall', 'Пожарные']
      ];
      scope.evLabels = {accident: 'ДТП', breakdown: 'поломка', slow: 'тихоход', drunk: 'пьяный', race: 'гонка', chaseStart: 'погоня', policeStop: 'остановка'};

      function poll() {
        bngApi.engineLua('gameplay_liveTraffic and gameplay_liveTraffic.getStateJson() or ""', function (r) {
          scope.$evalAsync(function () {
            try { scope.st = r ? JSON.parse(r) : null; } catch (e) { scope.st = null; }
          });
        });
      }
      function lua(s) { bngApi.engineLua(s); }
      scope.set = function (k, v) {
        var p = {}; p[k] = v;
        lua('gameplay_liveTraffic.setSettingsJson(' + JSON.stringify(JSON.stringify(p)) + ')');
        if (scope.st) scope.st.settings[k] = v;
        setTimeout(poll, 150);
      };
      scope.flip = function (k) { scope.set(k, !scope.st.settings[k]); };
      scope.fire = function (n) { lua('gameplay_liveTraffic.trigger("' + n + '")'); setTimeout(poll, 300); };
      scope.clearAll = function () { lua('gameplay_liveTraffic.clearAll()'); setTimeout(poll, 300); };
      scope.evText = function () {
        if (!scope.st || !scope.st.events.length) return '—';
        return scope.st.events.map(function (e) { return scope.evLabels[e] || e; }).join(', ');
      };

      poll();
      var t = $interval(poll, 1000);
      scope.$on('$destroy', function () { $interval.cancel(t); });
    }
  };
}]);
